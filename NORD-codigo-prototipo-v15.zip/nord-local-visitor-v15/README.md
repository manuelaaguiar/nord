# NÓRD · travel club demonstration

A responsive browser-local journey workspace with a blank “Create my trip” flow and a separate editable fictional example. Visitors can edit routes, recover removed stages, change task status, maintain packing lists, enter budgets and write formatted journal pages. The original Luna is displayed as a demonstration only, without AI calls. No visitor record is sent to the application server.

## Public safety boundary

`lib/demo-boundary.ts` runs first in `build/sites-worker.ts`. It permits public presentation routes/assets and rejects every data API, unknown route and mutation with 403 and no-store. This includes state, history, full export, journal, media and paid AI. Identity or service headers do not bypass it. No owner authentication is currently provisioned in the app, so the private backend is unavailable to everyone through public HTTP.

The previously stored D1/R2 data is preserved on the hosting platform and never included in this repository/export. No migration/reset is required. The synthetic seed is only an isolated test fixture; it does not replace existing production state. Private backend implementations and recovery tests remain for future authorized work, but are unreachable in this demo. Do not roll back to an older private implementation while public sharing is enabled.

## Typography and accessibility

Play: functional headings. Cousine: technical details and numeric data. Cormorant Garamond: editorial moments. Apple system fonts where available, with local DM Sans fallback: body and controls. Font license files are in `public/nord/design/fonts/`. Glass effects use opaque fallbacks, limited mobile blur and reduced-transparency/motion preferences. Luna and the brand are preserved.

## Development and verification

Install dependencies with the repository package manager, run `npm test`, `npm run typecheck`, `npm run lint`, then build through the Sites workflow. `npm run check:secrets` checks build output for credential patterns. Public demo tests verify denial for anonymous, forged-header and service-header requests before framework handling; client code has no server network/mutation operations. Local records use a new namespace, never the earlier private-app storage. Historical storage tests run against synthetic in-memory SQLite and simulated browser/network storage, never production.

The manifest offers standalone presentation and an iPhone home-screen help panel. The demo requires connectivity. It is not an App Store application, and automated browser checks do not constitute a physical iPhone/Safari test.

## Data and restoration

Existing revision history and private media stay in the original hosted project. Credentials, databases, uploads, exports, local browser drafts, `.git` history and environment files must not enter a source ZIP or a GitHub backup. A future private application requires verified owner binding, reader approval/revocation, server-side permissions for every API/media route and a defined authenticated service-access path before removing the deny boundary.

## Local records and limitations
Personal and example journeys are separate localStorage keys. Every committed field or journal edit is saved locally, with a visible pending/error state. Web Locks serialize cross-tab writes; stale revisions preserve the losing edit rather than overwriting. If storage is full/blocked or Web Locks unavailable, the page retains edits in memory and offers a JSON download. Reload cannot recover unsaved memory: download first. Corrupt originals are not reset. Removing a route stage archives it for recovery; example reset asks confirmation and leaves the personal journey untouched.

There is no account-based isolation. Anyone using the same browser profile can see its records. Private browsing, browser cleanup and device loss can remove data. No device sync or automatic backup is provided. A manual JSON download preserves a portable copy, but this version does not import it. Journal text is typed paragraphs/runs, not stored HTML; paste is plain text and rendering escapes content. Attachments/audio and AI remain disabled for visitors. Browser-local storage is explicitly authorized for the public visitor prototype and does not change the pre-existing owner's canonical D1/R2 data.
