# NÓRD v15 · executar e preservar

Código do protótipo público editável localmente: cria uma viagem vazia, mantém um exemplo separado, permite editar roteiro, tarefas, bagagem, orçamento e diário. Os registros ficam neste perfil de navegador, sem sincronização entre aparelhos. Limpar dados do navegador ou usar navegação privada pode apagar registros. O download JSON é cópia manual; esta versão não importa o JSON. IA, anexos e áudio de visitantes continuam desativados.

Este pacote contém código, testes, assets e licenças; não contém registros de visitantes, dados pessoais da proprietária, banco, anexos, credenciais ou histórico Git. As implementações privadas preservadas no código continuam bloqueadas pelo Worker. Não remova a fronteira de segurança nem execute seeds, resets ou migrações de produção para testar.

## Requisitos e comandos

Node.js 22.13 ou superior e pnpm 11.25.0, conforme package.json. A instalação exige acesso ao registro oficial npm.

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm typecheck
pnpm lint
pnpm build
pnpm check:secrets
pnpm dev
```

A prévia portátil usa a porta 5173. Após compilar, `pnpm start` executa o Worker local. Verifique a fronteira de APIs no Worker compilado; a prévia inclui mocks de desenvolvimento. `.env.example` só contém opções não secretas. Não é necessária chave de IA para este protótipo.

`.openai/hosting.json` preserva o identificador do projeto original e nomes de bindings, sem credenciais. Não publique automaticamente noutro destino. Os dados privados D1/R2 permanecem no projeto original, fora deste ZIP.

## Assets e integridade

Fontes locais incluem suas licenças OFL; componentes vendorizados incluem avisos correspondentes. A imagem Luna e identidade NÓRD foram preservadas do material fornecido pela proprietária; este pacote não concede nova licença de redistribuição pública. Fontes Apple são referenciadas como fontes de sistema, não distribuídas.

O manifesto de origem identifica o commit 7ae65d4c54b0fb5702a4fad9567bc6041c15cb4c. O manifesto do pacote descreve todos os arquivos entregues e seus hashes. Nenhum código foi alterado ao empacotar; acrescentaram-se somente documentação e `.env.example`.

## GitHub

Este ZIP ainda não foi salvo no GitHub. O repositório existente `manuelaaguiar/nord` é público e não foi usado. Um destino privado precisa estar disponível antes do envio. Nunca envie `.env` real, `.git` antigo, banco, uploads, estado Wrangler ou registros locais do visitante.
