/** Public demo has no data principal. Neither a browser identity header nor a
 * dispatch service credential grants access to the preserved private backend.
 * This is deliberately fail-closed until a separate owner ACL is verified. */
export function demoBoundary(request: Request): Response | null {
  const path = new URL(request.url).pathname;
  const read = request.method === 'GET' || request.method === 'HEAD';
  if (read && (path === '/' || path === '/dashboard' || path === '/dashboard/')) return null;
  if (read && (path === '/favicon.svg' || /^\/nord\/[a-zA-Z0-9_./-]+$/.test(path) || path.startsWith('/assets/'))) return null;
  return Response.json({mode:'demonstration',error:'Esta demonstração é somente leitura. Dados pessoais, anexos e a IA não estão disponíveis.'},{status:403,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'",'Referrer-Policy':'no-referrer'}});
}
